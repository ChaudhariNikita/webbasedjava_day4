package example.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class GreetingServlet
 */
public class GreetingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	public void init() {
		System.out.println("inside init()");
	}
	
	@Override
	public void destroy() {
		System.out.println("inside destroy()");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("inside doGet()");
		//this method gets invoked when the servlet is requested
		//this method is sending html response back to client
		//setting the MIME type for html response
		//MIME=>Multi-purpose Internet Mail Extension(text/html)
		response.setContentType("text/html");
		
		//obtaining a writer object to send the response
		PrintWriter out=response.getWriter();
		
		//seeting the response text
		String responseText="<h1 style='color:red'>Welcome to servlet</h1>";
		
		//sending the response
		out.println(responseText);
	}

}
